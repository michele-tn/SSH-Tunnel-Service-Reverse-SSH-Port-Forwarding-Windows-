using System;
using System.Collections.Generic;
using System.Threading;
using Renci.SshNet;
using SshTunnelService.Core.Models;
using SshTunnelService.Infrastructure;

namespace SshTunnelService.Core.Services
{
    public class SshTunnelManager
    {
        private readonly string _host;
        private readonly int _port;
        private readonly string _username;
        private readonly string _privateKeyPath;
        private readonly List<TunnelDefinition> _tunnels;
        private SshClient _client;
        private readonly LoggingService _logger;

        public SshTunnelManager(string host, int port, string username, string privateKeyPath, List<TunnelDefinition> tunnels, LoggingService logger)
        {
            _host = host;
            _port = port;
            _username = username;
            _privateKeyPath = privateKeyPath;
            _tunnels = tunnels;
            _logger = logger;
        }

        public void Start()
        {
            Thread worker = new Thread(RunTunnelLoop);
            worker.IsBackground = true;
            worker.Start();
        }

        private void RunTunnelLoop()
        {
            while (true)
            {
                try
                {
                    ConnectAndStartTunnels();
                    _logger.Info("All tunnels started successfully.");

                    while (_client.IsConnected)
                        Thread.Sleep(5000);
                }
                catch (Exception ex)
                {
                    _logger.Error("Error in SSH tunnel: " + ex.Message);
                }

                _logger.Info("Reconnecting in 10 seconds...");
                Thread.Sleep(10000);
            }
        }

        private void ConnectAndStartTunnels()
        {
            using (var keyFile = new PrivateKeyFile(_privateKeyPath))
            {
                var connectionInfo = new ConnectionInfo(_host, _port, _username, new PrivateKeyAuthenticationMethod(_username, keyFile));
                _client = new SshClient(connectionInfo);
                _client.Connect();

                foreach (var tunnel in _tunnels)
                {
                    var fwd = new ForwardedPortRemote(tunnel.RemoteHost, tunnel.RemotePort, tunnel.LocalHost, tunnel.LocalPort);
                    _client.AddForwardedPort(fwd);
                    fwd.Start();
                    _logger.Info($"Tunnel started: {tunnel.RemoteHost}:{tunnel.RemotePort} → {tunnel.LocalHost}:{tunnel.LocalPort}");
                }
            }
        }

        public void Stop()
        {
            if (_client != null && _client.IsConnected)
                _client.Disconnect();
            _logger.Info("SSH tunnels stopped.");
        }
    }
}
