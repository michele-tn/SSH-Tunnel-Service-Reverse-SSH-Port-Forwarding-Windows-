using System;
using System.IO;

namespace SshTunnelService.Infrastructure
{
    public class LoggingService
    {
        private readonly string _logFilePath;

        public LoggingService()
        {
            string logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
            Directory.CreateDirectory(logDir);
            _logFilePath = Path.Combine(logDir, "service.log");
        }

        public void Info(string message) => Write("INFO", message);
        public void Error(string message) => Write("ERROR", message);

        private void Write(string level, string message)
        {
            string logMessage = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] {message}";
            File.AppendAllLines(_logFilePath, new[] { logMessage });
        }
    }
}
