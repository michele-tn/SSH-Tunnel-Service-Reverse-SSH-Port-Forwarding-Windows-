using System.ServiceProcess;

namespace SshTunnelService.ServiceHost
{
    internal static class Program
    {
        static void Main()
        {
            ServiceBase.Run(new TunnelService());
        }
    }
}
