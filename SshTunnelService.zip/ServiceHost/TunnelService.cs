using System;
using System.Collections.Generic;
using System.ServiceProcess;
using SshTunnelService.Core.Models;
using SshTunnelService.Core.Services;
using SshTunnelService.Infrastructure;

namespace SshTunnelService.ServiceHost
{
    public class TunnelService : ServiceBase
    {
        private SshTunnelManager _manager;
        private LoggingService _logger;

        public TunnelService()
        {
            this.ServiceName = "SshTunnelService";
        }

        protected override void OnStart(string[] args)
        {
            _logger = new LoggingService();

            var tunnels = new List<TunnelDefinition>
            {
                new TunnelDefinition("127.0.0.1", 9389, "127.0.0.1", 3389),
                new TunnelDefinition("127.0.0.1", 9922, "127.0.0.1", 22)
            };

            _manager = new SshTunnelManager("5.250.191.95", 3422, "guest",
                AppDomain.CurrentDomain.BaseDirectory + "Resources/guest_private_key.pem",
                tunnels, _logger);

            _manager.Start();
            _logger.Info("Service started.");
        }

        protected override void OnStop()
        {
            _manager.Stop();
            _logger.Info("Service stopped.");
        }
    }
}
