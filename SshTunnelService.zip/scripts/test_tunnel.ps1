Test-NetConnection -ComputerName 127.0.0.1 -Port 9389
Test-NetConnection -ComputerName 127.0.0.1 -Port 9922
