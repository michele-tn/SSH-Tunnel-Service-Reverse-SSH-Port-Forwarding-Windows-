Stop-Service -Name "SshTunnelService" -ErrorAction SilentlyContinue
sc.exe delete "SshTunnelService"
