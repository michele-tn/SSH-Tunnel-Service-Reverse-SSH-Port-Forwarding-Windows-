New-Service -Name "SshTunnelService" -BinaryPathName ""$PSScriptRoot\..\bin\Debug\SshTunnelService.exe"" -DisplayName "SSH Tunnel Service" -StartupType Automatic
Start-Service -Name "SshTunnelService"
